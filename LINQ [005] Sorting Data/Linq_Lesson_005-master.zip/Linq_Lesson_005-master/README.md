# Linq_Lesson_005
## Some modification
