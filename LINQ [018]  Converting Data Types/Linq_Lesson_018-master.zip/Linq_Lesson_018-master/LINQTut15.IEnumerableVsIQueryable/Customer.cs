﻿namespace LINQTut17.ExpressionTree04
{
    class Customer
    {
        public string Name { get; set; }
        public bool IsVip { get; set; }
    }
}
