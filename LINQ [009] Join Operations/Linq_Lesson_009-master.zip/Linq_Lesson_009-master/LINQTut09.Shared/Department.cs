﻿namespace LINQTut09.Shared
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
