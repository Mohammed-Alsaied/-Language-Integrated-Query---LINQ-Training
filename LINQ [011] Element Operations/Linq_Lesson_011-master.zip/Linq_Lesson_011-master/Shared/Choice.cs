﻿
namespace Shared
{
    public class Choice
    {
        public int Order { get; set; }
        public string Description { get; set; }
    }
}
