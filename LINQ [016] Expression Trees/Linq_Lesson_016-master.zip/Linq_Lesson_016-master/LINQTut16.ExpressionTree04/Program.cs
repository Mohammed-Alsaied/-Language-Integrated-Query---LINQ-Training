﻿using System;

namespace LINQTut16.ExpressionTree04
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            Console.ReadKey();
        }
    }
}
